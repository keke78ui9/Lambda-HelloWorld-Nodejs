exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: "New version from Zip function!",
    };
    return response;
};
